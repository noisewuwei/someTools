# Contributing

1. This project uses the [WebKit style guide](https://webkit.org/code-style-guidelines/)

2. Run `make lint-fix` to auto-format your code.

3. Run `make && ./osx-cpu-temp` to test it still works
